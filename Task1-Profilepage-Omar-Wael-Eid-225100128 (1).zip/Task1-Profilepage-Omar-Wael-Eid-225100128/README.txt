Task 1 — Profile Page

Student: Omar Wael Eid
Student ID: 225100128

Open index.html in a browser to view the page.
The image in images/me.jpg is a temporary placeholder avatar. Replace it with a personal photo if required.
